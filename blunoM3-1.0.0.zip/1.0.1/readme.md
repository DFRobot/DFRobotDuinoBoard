# DFRobot
This is DFRobot core source files, make Arduino IDE supports STM32F103XX cortex-m3 arm cpu.
#how to install and build the deverlopment environment, you can link to these web site:

1. http://wiki.dfrobot.com.cn/index.php?title=ARDUINO1.6.5%E5%8F%8A%E5%85%B6%E4%BB%A5%E4%B8%8A%E7%89%88%E6%9C%AC%E6%94%AF%E6%8C%81Bluno_M3%E6%95%99%E7%A8%8B&action=edit&redlink=1

2.http://wiki.dfrobot.com.cn/index.php?title=(SKU:DFR0329)Bluno_M3%E6%8E%A7%E5%88%B6%E5%99%A8_%E5%85%BC%E5%AE%B9Arduino
# Todo
more info.
www.DFRobot.com
